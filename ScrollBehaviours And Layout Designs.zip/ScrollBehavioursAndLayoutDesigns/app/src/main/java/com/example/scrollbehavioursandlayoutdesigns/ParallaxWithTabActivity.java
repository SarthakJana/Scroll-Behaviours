package com.example.scrollbehavioursandlayoutdesigns;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ParallaxWithTabActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab_with_parallax);
    }
}
